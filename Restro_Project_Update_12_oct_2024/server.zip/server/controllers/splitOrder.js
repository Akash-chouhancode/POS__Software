const db = require("../utils/db");

const dbQuery = (query, values) => {
    return new Promise((resolve, reject) => {
      db.pool.query(query, values, (err, result) => {
        if (err) {
          return reject(err);
        }
        resolve(result);
      });
    });
  };

  const showsplitorder = async (req, res) => {
    try {
      const orderId = req.params.id;
  
      // Validate orderId
      if (!orderId) {
        return res.status(400).json({ message: "Order ID is required" });
      }
  
      // Fetch order information
      const orderQuery = `SELECT * FROM customer_order WHERE order_id = ?`;
      db.pool.query(orderQuery, [orderId], (err, orderResult) => {
        if (err) {
          console.error("Error fetching order information:", err);
          return res.status(500).json({ message: "Error fetching order information" });
        }
  
        if (!orderResult || orderResult.length === 0) {
          return res.status(404).json({ message: "Order not found" });
        }
  
        // Fetch order menu items
        const getOrderMenuQuery = `
          SELECT
              om.*,
              f.*,
              v.variantName,
              GROUP_CONCAT(a.add_on_id) AS add_on_ids,
              GROUP_CONCAT(a.add_on_name) AS add_on_names,
              GROUP_CONCAT(a.price) AS add_on_prices
          FROM
              order_menu om
              LEFT JOIN add_ons a ON FIND_IN_SET(a.add_on_id, om.add_on_id)
              LEFT JOIN item_foods f ON om.menu_id = f.ProductsID
              LEFT JOIN variant v ON om.varientid = v.variantid
          WHERE
              om.order_id = ?
          GROUP BY om.menu_id, om.varientid;
        `;
  
        db.pool.query(getOrderMenuQuery, [orderId], (err, menuResult) => {
          if (err) {
            console.error("Error fetching menu items:", err);
            return res.status(500).json({
              success: false,
              message: "An error occurred while fetching menu items",
            });
          }
  
          // Process menuResult to structure add-on data
          const structuredMenuItems = menuResult.map((item) => {
            const addOnIds = item.add_on_ids ? item.add_on_ids.split(",") : [];
            const addOnNames = item.add_on_names ? item.add_on_names.split(",") : [];
            const addOnPrices = item.add_on_prices ? item.add_on_prices.split(",") : [];
            const addOnQuantities = item.addonsqty ? item.addonsqty.split(",") : [];
  
            const addOns = addOnIds.map((id, index) => ({
              add_on_id: id,
              add_on_name: addOnNames[index] || null,
              add_on_price: addOnPrices[index] || null,
              add_on_quantity: addOnQuantities[index] || null,
            }));
  
            return {
              ...item,
              add_ons: addOns,
            };
          });
  
          // Send response
          res.status(200).json({
            order: orderResult[0],
            menuItems: structuredMenuItems,
            message: "Split order data fetched successfully",
          });
        });
      });
    } catch (error) {
      console.error("Error in showsplitorder:", error);
      res.status(500).json({ message: "Server error", error });
    }
  };

  module.exports={
    showsplitorder,
  }