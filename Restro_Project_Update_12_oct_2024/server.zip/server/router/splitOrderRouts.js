const express= require ("express")
const router = express.Router();

const splitcontroller= require("../controllers/splitOrder");

router.get ("/splitorderdata/:id",splitcontroller.showsplitorder)
module.exports=router