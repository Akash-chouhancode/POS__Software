import React from "react";

const KitchenDashboard = () => {
  return <div>KitchenDeshbord</div>;
};

export default KitchenDashboard;
